const redTeam = document.querySelector('.redTeam')
const blueTeam = document.querySelector('.blueTeam')
const bluetip = document.querySelector('.blue')
const orangetip = document.querySelector('.orange')
let red = 0
let blue = 0
redTeam.addEventListener('click',function(){
    const sum = document.querySelector('.leftbox span')
    red ++ 
    sum.innerHTML = red
    const reluit = (red/(red + blue) * 100).toFixed(2) + '%'
    bluetip.innerHTML = reluit 
    const reluit1 = (blue/(red + blue) * 100).toFixed(2) + '%'
    orangetip.innerHTML = reluit1
    let all = parseInt(reluit)/100
    bluetip.style.width = all*600 + 'px'
    orangetip.style.width = (1 - all)*600 + 'px'
})
blueTeam.addEventListener('click',function(){
    const sum = document.querySelector('.rightbox span')
    blue ++ 
    sum.innerHTML = blue
    const reluit = (blue/(red + blue) * 100).toFixed(2) + '%'
    orangetip.innerHTML = reluit 
    const reluit1 = (red/(red + blue) * 100).toFixed(2) + '%'
    bluetip.innerHTML = reluit1
    let all = parseInt(reluit)/100
    orangetip.style.width = all*600 + 'px'
    bluetip.style.width = (1 - all)*600 + 'px'
})