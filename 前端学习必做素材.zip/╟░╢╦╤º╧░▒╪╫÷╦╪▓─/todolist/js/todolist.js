// ● 代办事项列表
function getData() {
    localArr = JSON.parse(localStorage.getItem('value')) || []
}
getData()

function loads(datas) {
    const ul = document.querySelector('.todo-list')
    const item = document.querySelector('.todo-count strong')
    // doing.forEach(ele => done.unshift(ele))
    const arr = []
    datas.forEach((ele, index) => {
        arr.push(
            `<li class="${ele.done ? 'completed' : ''}">
                        <div class="view">
                            <input id='toggle${index}' class="toggle" type="checkbox" ${ele.done ? 'checked' : ''} data-id=${index}>
                            <label for='toggle${index}'>${ele.text}</label>
                            <button class="destroy" data-index='${index}'></button>
                        </div>
                        <input class="edit" value="Create a TodoMVC template">
                    </li>`
        )
    });
    ul.innerHTML = arr.join('')
    // console.log(datas);
    // ● 显示未完成的条目
    const lens = (datas.filter(ele => !ele.done)).length
    item.innerHTML = lens
}
loads(localArr)


// ● 制作一个更新本地存储的函数

function saveData(todos) {
    localStorage.setItem('value', JSON.stringify(todos))
}

// ● 录入待办事项

const text = document.querySelector('.new-todo')
text.addEventListener('keyup', function (e) {
    // console.log(e.keyCode);
    if (e.keyCode == 13) {
        if (this.value.trim() == '') {
            this.value = ''
            return alert('请输入文字')
        } else {
            const data = localArr
            data.unshift({ text: this.value, done: false })
            saveData(localArr)
            loads(data)
            this.value = ''
        }
    }
})

// ● 删除选中的条目

const todolist = document.querySelector('.todo-list')
todolist.addEventListener('click', function (e) {
    // console.log(e.target.matches('.destroy'));
    if (e.target.matches('.destroy')) {
        localArr.splice(e.target.dataset.index, 1)
        saveData(localArr)
        loads(localArr)
    }

    //把没有全选的模块写在这里
    if (e.target.matches('.toggle')) {
        const toggle = document.querySelector('.toggle-all')
        const lis = document.querySelectorAll('.toggle').length
        const index = e.target.dataset.id
        localArr[index].done = e.target.checked
        // console.log(localArr[index]);
        saveData(localArr)
        const len = (localArr.filter(ele => ele.done)).length
        if (len == lis) {
            toggle.checked = true
        } else {
            toggle.checked = false
        }
        loads(localArr)
    }
})




// ● 全选功能和未全选功能
// ● 未全选功能卸载删除选中的条目中
const toggle = document.querySelector('.toggle-all')
toggle.addEventListener('click', function () {
    // console.log(this.checked);
    const lis = document.querySelectorAll('.toggle')
    lis.forEach((ele) => {
        // console.log(ele);
        ele.checked = this.checked
    })
    // 保存下来
    // console.log(localArr);
    localArr.forEach(ele => {
        ele.done = this.checked
    })
    saveData(localArr)
    loads(localArr)
})




// ● 清除所有完成项

const clear = document.querySelector('.clear-completed')
clear.addEventListener('click', function (e) {
    const done = (localArr.filter(ele => !ele.done))
    saveData(done)
    loads(done)
    getData()
})



// ● 筛选待办事项或者已办事项
const screen = document.querySelector('.filters')
screen.addEventListener('click', function (e) {
    if (e.target.tagName === 'A') {
        if (e.target.parentNode.innerText === 'All') {
            // console.log(11);
            loads(localArr)
        } else if (e.target.parentNode.innerText === 'Active') {
            let arr = localArr.filter(ele => !ele.done)
            loads(arr)
        } else {
            let arr = localArr.filter(ele => ele.done)
            loads(arr)
        }
    }
})
