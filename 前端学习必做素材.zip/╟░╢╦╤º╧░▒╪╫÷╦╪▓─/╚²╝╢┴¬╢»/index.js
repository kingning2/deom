const all = [
    {
        id: 1001,
        name: '广东省',
        children: [
            {
                name: '深圳',
                children: ['宝安', '龙湖', '坪山']
            },
            {
                name: '汕头',
                children: ['潮阳', '潮南', '澄海']
            },
            {
                name: '佛山',
                children: ['南海', '顺德', '三水']
            },
            {
                name: '惠州',
                children: ['惠城', '惠阳', '惠东']
            },
        ]
    },
    {
        id: 1002,
        name: '辽宁省',
        children: [
            {
                name: '沈阳',
                children: ['和平', '沈河', '皇姑']
            },
            {
                name: '大连',
                children: ['中山', '沙河口', '沈阳']
            },
            {
                name: '本溪',
                children: ['平山', '溪湖', '明山']
            },
            {
                name: '辽阳',
                children: ['辽阳', '辽阳', '宏伟']
            },
        ]
    },
    {
        id: 1003,
        name: '北京市',
        children: ['朝阳', '海淀', '西城']
    },
    {
        id: 1004,
        name: '上海市',
        children: ['黄浦', '静安', '长宁']
    }
]
const province = document.querySelector('#province')
const city = document.querySelector('#city')
const district = document.querySelector('#district')
const frag = document.createDocumentFragment();
// 省的改变
for(let i =0;i<all.length;i++){
    const option = document.createElement('option')
    option.innerHTML = all[i].name
    frag.appendChild(option)
}
province.appendChild(frag)
province.addEventListener('change',function(){
    // 市的改变
    let cityarr = []
    let districtarr = []
    city.innerHTML = '<option value="">-- 请选择 --</option>'
    district.innerHTML = '<option value="">-- 请选择 --</option>'

    for(let i=0;i<all.length;i++){
        if(all[i].name == this.value){
            if(all[i].children[0].name){
                city.style.display = 'inline'
                cityarr = all[i].children
            }else{
                city.style.display = 'none'
                districtarr = all[i].children
                for(let i = 0;i<districtarr.length;i++){
                    const option = document.createElement('option')
                    option.innerHTML = districtarr[i]
                    district.appendChild(option)
                }             
            }           
        }
    }

    for(let i =0;i<cityarr.length;i++){
        const option = document.createElement('option')
        option.innerHTML = cityarr[i].name
        city.appendChild(option)
    }
    // 区的改变
    city.addEventListener('change',function(){
        district.innerHTML = '<option value="">-- 请选择 --</option>'
        for(let i =0;i<cityarr.length;i++){
            if(cityarr[i].name == this.value){
                districtarr = cityarr[i].children
            }
        }
        for(let i = 0;i<districtarr.length;i++){
            const option = document.createElement('option')
            option.innerHTML = districtarr[i]
            district.appendChild(option)
        }
    })
})
